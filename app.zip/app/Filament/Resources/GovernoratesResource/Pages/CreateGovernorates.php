<?php

namespace App\Filament\Resources\GovernoratesResource\Pages;

use App\Filament\Resources\GovernoratesResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateGovernorates extends CreateRecord
{
    protected static string $resource = GovernoratesResource::class;
}
